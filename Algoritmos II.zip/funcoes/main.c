#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>



//sem paramentro e sem retorn
void soma()
{
int num1, num2,result;
printf("Digite o primeiro valor");
scanf("%d", &num1);
printf("Digite o segundo valor");
scanf("%d", &num2);
printf("%d", num1+num2);
}
void subtrai()
{
int num3, num4,result2;
printf("Digite o primeiro valor");
scanf("%d", &num3);
printf("Digite o segundo valor");
scanf("%d", &num4);
printf("%d", num3-num4);
}
void divide(){
 float num5,num6,result3;
 printf("Digite o primeiro valor");
scanf("%d", &num5);
printf("Digite o segundo valor");
scanf("%d", &num6);
printf("%d", num5/num6);


}
