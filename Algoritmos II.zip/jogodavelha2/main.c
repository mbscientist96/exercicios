#include <stdio.h>
#include <stdlib.h>


char jogo_davelha[3] [3];
char jogador1 [50], jogador2 [50];

void comecaojogo(){
int x,y;
for(x=0; x<3; x++){
        for(y=0; y<3; y++){
                jogo_davelha[x][y] = 'a';
        }
        }

}

