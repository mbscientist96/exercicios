#include <stdio.h>
#include <stdlib.h>



int main()
{



float x = 0.0;
int lin,col,v_col,v_lin;



printf("Defina o numero de LINHAS (minimo 2; maximo 5)\n");
scanf("%d%*c",&v_lin);
printf("\nDefina o numero de COLUNAS (minimo 2; maximo 5)\n");
scanf("%d%*c",&v_col);



if ((v_lin >= 2 )&&(v_lin <= 5)&& (v_col >= 2 )&&(v_col <= 5)){
float a [v_lin][v_col];



for (lin=0;lin<v_lin;lin++){
for(col=0;col<v_col;col++){
a [lin][col]= x;
x = x + 0.5;
}
}
for (lin=0;lin<v_lin;lin++){
for(col=0;col<v_col;col++){
printf("%.1f ",a[lin][col]);
}
printf("\n");
}
}
else{
printf("Numero de linhsa ou colunas invalido!");
}
return 0;
}
