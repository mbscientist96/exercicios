#include <stdio.h>
#include <stdlib.h>

int main()
{
     float nota[10]= {8,7,9,4,6,5,3,6,9};
      float soma;
      float divide;

   for(int i=0; i<10; ++i){
    printf("%i\n",nota[i]);
   }
     soma=nota[i]+nota[i];
     divide=nota/2
   printf("total � de %d",nota);
   printf("m�dia � de %d", divide);
    return 0;
}
