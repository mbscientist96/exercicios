#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void){setlocale(LC_ALL, "Portuguese");
    char nome[7][50]; // 7 linhas para cada nome e 50 caracteres
    float media_final[7]; // vetor para m�dia final de cada aluno
    float maior; // vari�vel para maior m�dia
    int ind; //indice para o la�o de repeti��o "for", adiciona +1
    int j;  // recebe valor de indice

    for(ind = 0; ind < 7; ind++){
        printf("Insira o nome do aluno %d: ", ind+1);
        fgets(nome[ind], 35, stdin);
        // escreve os nomes de cada um aluno com o total de 7
    }

    system("cls");

    for(ind = 0; ind < 7; ind++){
        printf("Digite a m�dia final do aluno %d: ", ind+1);
        scanf("%f", &media_final[ind]);
        //Digitar a media final de cada aluno
    }

    system("cls");

    maior = media_final[0];
    printf("ALUNO COM A MAIOR M�DIA\n");
    for(ind = 0; ind < 7; ind++){
        if (maior < media_final[ind]){
            maior = media_final[ind];
            j = ind;
            // imprime na tela a maior media do aluno com a condi��o de se for maior
        }
    }
    printf("M�dia: %.2f - %s", media_final[j], nome[j]);

    printf("\n\nALUNOS ABAIXO DA M�DIA\n");
    for(ind = 0; ind < 7; ind++){
        if (media_final[ind] < 7){
            printf("\nAluno: %sM�dia: %.2f \n Faltam: %.2f\n", nome[ind], media_final[ind], 10 - media_final[ind]);
            // caso a condi��o for menor que a m�dia, ir� imprimir na tela o quanto falta para o aluno ser aprovado
        }
    }

}
