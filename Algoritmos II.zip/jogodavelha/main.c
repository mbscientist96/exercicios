#include <stdio.h>
#include <stdlib.h>

char jogo[3][3];
char jogador1[50], jogador2[50];

void inicializarJogo() {
    int i, j;
    for(i = 0; i < 3; i++) {
        for(j = 0; j < 3; j++) {
            jogo[i][j] = 'a';
        }
    }
}
