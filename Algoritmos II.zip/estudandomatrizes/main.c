//Nome: Matheus Fernando Beraldo RA: 202110032
#include <stdio.h>
#include <stdlib.h>
void jogo(char posicao2 [3] [3]){
    system("cls");
    printf("\t %c | %c | %c | \n",posicao2[0][0],posicao2[0][1],posicao2[0][2]);
    printf("\t-----------------\n");
    printf("\t %c | %c | %c | \n",posicao2[1][0],posicao2[1][1],posicao2[1][2]);
    printf("\t-----------------\n");
    printf("\t %c | %c | %c | \n",posicao2[2][0],posicao2[2][1],posicao2[2][2]);
//Fun��o para mostrar o tabuleiro
}
int main()
{
    //Fun��o princiapal para iniciar as vari�veis
    char posicao[3][3] = { {'1','2','3'},
                           {'4','5','6'},
                           {'7','8','9'},};

    char resposta;
    int cont_jogadas,l,c,vez=0,i,j;

    do{
        cont_jogadas = 1;
        for(i=0;i<=2;i++){
        for(j=0;j<=2;j++){
            posicao[i][j]=' ';
            //Iniciando a primeira jogada e limpando o tabuleiro
        }
    }
    do{
        jogo(posicao); //repeti��o para mostrar o tabuleiro e a vez do jogador
        if(vez%2==0){
            printf("jogador X \n");
        }
        else{
            printf("jogador O \n");
        }
        printf("Digite a linha: ");
        scanf("%i",&l);
        printf("Digite a coluna: ");
        scanf("%i",&c);
        //Digitar linha e coluna para saber onde colocar o X e O
        if (l < 1|| c < 1|| l > 3 || c > 3 ){
            l=0;
            c=0;

        }
        else if(posicao[l-1][c-1]!=' '){
            l=0;
            c=0;
        }
        else{
            if(vez%2==0){
                posicao[l-1][c-1] = 'X';
            }
            else{
                posicao[l-1][c-1] = 'O';

        }
        vez++;
        cont_jogadas++;
        }
        //Se estiver certo a jogada ele marca como a outra vez do jogador, se colocar a mesma linha que o outro jogador colocou ele repete at� colocar a linha e coluna certa

        //condi��es de vit�ria do X
    if (posicao[0][0]=='X' && posicao[0][1]=='X'&& posicao[0][2]=='X'){cont_jogadas=11;}
    if (posicao[1][0]=='X' && posicao[1][1]=='X'&& posicao[1][2]=='X'){cont_jogadas=11;}
    if (posicao[2][0]=='X' && posicao[2][1]=='X'&& posicao[2][2]=='X'){cont_jogadas=11;}
    if (posicao[0][0]=='X' && posicao[1][0]=='X'&& posicao[2][0]=='X'){cont_jogadas=11;}
    if (posicao[0][1]=='X' && posicao[1][1]=='X'&& posicao[2][1]=='X'){cont_jogadas=11;}
    if (posicao[0][2]=='X' && posicao[1][2]=='X'&& posicao[2][2]=='X'){cont_jogadas=11;}
    if (posicao[0][0]=='X' && posicao[1][1]=='X'&& posicao[2][2]=='X'){cont_jogadas=11;}
    if (posicao[0][2]=='X' && posicao[1][1]=='X'&& posicao[2][0]=='X'){cont_jogadas=11;}
     //Condi��es de vit�ria da O
    if (posicao[0][0]=='O' && posicao[0][1]=='O'&& posicao[0][2]=='O'){cont_jogadas=12;}
    if (posicao[1][0]=='O' && posicao[1][1]=='O'&& posicao[1][2]=='O'){cont_jogadas=12;}
    if (posicao[2][0]=='O' && posicao[2][1]=='O'&& posicao[2][2]=='O'){cont_jogadas=12;}
    if (posicao[0][0]=='O' && posicao[1][0]=='O'&& posicao[2][0]=='O'){cont_jogadas=12;}
    if (posicao[0][1]=='O' && posicao[1][1]=='O'&& posicao[2][1]=='O'){cont_jogadas=12;}
    if (posicao[0][2]=='O' && posicao[1][2]=='O'&& posicao[2][2]=='O'){cont_jogadas=12;}
    if (posicao[0][0]=='O' && posicao[1][1]=='O'&& posicao[2][2]=='O'){cont_jogadas=12;}
    if (posicao[0][2]=='O' && posicao[1][1]=='O'&& posicao[2][0]=='O'){cont_jogadas=12;}

    }



while(cont_jogadas<=9);
jogo(posicao);
if (cont_jogadas==10){
    printf("Jogo empatado \n");
}
if(cont_jogadas==11){
    printf("Jogador de X venceu \n");
}
if(cont_jogadas==12){
        printf("Jodador de O venceu \n");

}


    printf("Deseja jogar novamente ??? [S-N]\n"); //repeti��o infinta while para saber se o jogador quer jogar novamente caso aperte S, N finaliza
    scanf("%s",&resposta);

}

while(resposta=='s');
}
//Informa o resultado da partida e finaliza o programa


