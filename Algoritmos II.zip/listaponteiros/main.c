#include <stdio.h>

int
main ()
{

    int x = 9;
    int y = 8;

    if (&x > &y)
      {
	    printf ("A variavel x tem o maior endereco de memoria\n");
	        return;
      }
    printf ("A variavel y tem o maior endereco de memoria\n");

}
