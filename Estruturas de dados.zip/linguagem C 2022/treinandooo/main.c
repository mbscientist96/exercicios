#include <stdio.h>
#include <stdlib.h>
int multiplica(int x, int y){
    int resultado = x*y;
    return resultado;
}
int soma(int x,int y){
    int resultado2 = x+y;
    return resultado2;
}
float divide(float multiplica, float soma){
    float resultado3 = multiplica/soma;
    return resultado3;
}
int total(int x, int y, int b){
    float resultado4 = x+y+b;
    return resultado4;
}
void localAutomatica(){
    int x = 5, y = 4;
    int resultadovariavel = x*y;
    printf("Variavel Local %d \n", resultadovariavel);
}

int main()
{
      localAutomatica();
      localAutomatica();
      localAutomatica();
   int resultado = multiplica(3,2);
   int resultado2 = soma(6,6);
   float resultado3 = divide(resultado2,resultado);
   int resultado4 = total(resultado,resultado2,resultado3);

    printf("VALOR MULTIPLICADO: %d \n", resultado);
    printf("VALOR DA SOMA : %d \n", resultado2);
    printf("VALOR DA DIVISAO: %f \n",resultado3);
    printf("VALOR TOTAL: %d \n", resultado4);
    return 0;
}
