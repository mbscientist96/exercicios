#include <stdio.h>
#include <stdlib.h>
int fatorial(int x){
    int resultado;
    if (x==0){
       resultado = 1;
    }
    else{
        resultado = x * fatorial(x-1);
    }
    return resultado;
}
int main()
{
     int fatorial(int x);
    int resultado, numero;
    printf("Digite um numero");
    scanf("%d", &numero);

    resultado=fatorial(numero);
   printf("FATORIAL EH %d \n",resultado);
   system("pause");
    return 0;
}
