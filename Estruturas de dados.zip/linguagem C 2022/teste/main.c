#include <stdio.h>
#include <stdlib.h>

int* initVet(int* Size, int* maxSize);

void printVet(int* v, int size, int maxSize);

int* addVet(int* v, int* size, int* maxSize, int e);

int find(int* v, int size, int e);

int* removeVet(int* v, int* size, int* maxSize, int e);

int main() {

	int pos;
	int size, maxSize;
	int* vetor = initVet(&size, &maxSize);

	vetor = addVet(vetor, &size, &maxSize, 4);
	vetor = addVet(vetor, &size, &maxSize, 12);
	vetor = addVet(vetor, &size, &maxSize, 35);
	vetor = addVet(vetor, &size, &maxSize, 55);

	int i;
	for (i = 0; i < 1000; i++) {
		vetor = addVet(vetor, &size, &maxSize, i);
	}

	vetor = removeVet(vetor, &size, &maxSize, 4);

	printVet(vetor, size, maxSize);

	pos = find(vetor, size, 12);

	(pos == -1) ? printf("\nnao encontrado\n") : printf("\nencontrado na pos %d", pos);

	return 0;
}

int* initVet(int* Size, int* maxSize) {

	*Size = 0;
	*maxSize = 4;

	int* v = (int*)malloc(sizeof(int));

	if (v == NULL) { printf("Erro de memoria"); exit(2); }

	return v;
}

void printVet(int* v, int size, int maxSize) {

	int i;

	printf("tamanho do vetor: %d\n", size);
	printf("tamanho em bytes: %d\n", maxSize);

	if (size > 0) {

		printf("elementos do vetor: ");
		for (i = 0; i < size; i++)
			printf("%d ", v[i]);
	}
	else {

		printf("vetor vazio\n");

	}

}

int* addVet(int* v, int* size, int* maxSize, int e) {

	if (*size == 0) {

		v[*size] = e;
		(*size)++;

	}
	else {

		*maxSize += 4;
		v = (int*)realloc(v, *maxSize);

		if (v == NULL) { printf("Erro de memoria"); exit(2); }

		v[*size] = e;
		(*size)++;

	}

	return v;
}

int find(int* v, int size, int e) {

	int i;

	for (i = 0; i < size; i++) {

		if (e == v[i])
			return i;

	}

	return -1;
}

int* removeVet(int* v, int* size, int* maxSize, int e) {

	int x = find(v, *size, e);
	if (x == -1) {
		printf("valor nao encontrado\n");
		return v;
	}

	int* modificado;
	int i, j = 0;

	modificado = (int*)malloc(*maxSize - 4);

	if (modificado == NULL) { printf("erro de memoria\n"); exit(2); }

	for (i = 0; i < *size; i++) {
		if (i != x) {
			modificado[j] = v[i];
			j++;
		}
	}

	free(v);

	(*size)--;
	(*maxSize) -= 4;

	return modificado;

}
