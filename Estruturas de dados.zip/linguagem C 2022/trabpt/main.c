#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    //ponteiro para vetor
    int *p,i,qtd_elementos;
     int *p ( int *size , int *maxSize );

    // caso o valor da memoria n�o for suficiente, apresentar mensagem de erro e sair do sistema apertando 1
    printf("Digite a quantidade de elementos do vetor");
    scanf("%d", &qtd_elementos);
    if(p == NULL){
        printf("Erro de aloca��o de memoria");
        system("pause");
        exit(1);
    }
        printf("\n");

        for( i=0; i<qtd_elementos; i++){
            printf("Digite o elemento para a posicao [%d] : ",i);
            scanf("%d", &p[i]);
        }
        printf("\n");

           for(i=0; i<qtd_elementos; i++){
            printf("\n elementos da posicao do vetor [%d] = %d\n",i,p[i]);
            printf("Memory %i", &p);
        }
        printf("\n");
        free(p);
        system("pause");
        return 0;


    }
    int *p ( int *size , int *maxSize ){
         p = (int *)(malloc(qtd_elementos * sizeof(int)));
    }


