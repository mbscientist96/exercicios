#include <stdio.h>
#include <stdlib.h>
typedef struct no{
    int valor;
    struct no *prox;
    }No;

//inserir inicio
void inserir_no_inicio(No **lista, int num){
    No  *novo = malloc(sizeof(No));
    if (novo){
        novo->valor=num;
        novo->prox = *lista;
        *lista = novo;
        }
        else{
            printf("Erro na aloca��o de mem�ria!\n");
        }

    }

//inserir no fim
void inserir_no_fim (No **lista, int num){
    No *aux, *novo = malloc(sizeof (No));
    if(novo){
        novo->valor = num;
        novo->prox = NULL;
        // � o primeiro ???
        if (*lista==NULL)
            *lista = novo;
        else{
            aux = *lista;
            while(aux->prox)
                aux = aux -> prox;
            aux->prox=novo;
        }
    }
    else{
        printf("Erro na aloca��o de mem�ria!\n");
    }
}
// Inserir no meio
void inserir_no_meio(No **lista, int num, int ant){
    No *aux, *novo = malloc (sizeof (No));
    if (novo){
        novo->valor = num;
        // � o primeiro ???
        if(*lista == NULL){
            novo -> prox = NULL;
            *lista = novo;
        }
        else{
            aux = *lista;
            while(aux->valor != ant && aux->prox)
                aux = aux-> prox;
            novo->prox = aux->prox;
            aux->prox=novo;
        }
        }
        else printf("Erro na aloca��o de mem�ria");
    }
imprimir(No *no){
    printf("\n\t Lista:");
    while (no){
        printf(" %d \t ",no->valor);
        no = no->prox;
    }
    printf("\n\n");
}
//removendo elemento
No* remover(No **lista, int num){
    No *aux, *remover = NULL;
    if (*lista){
        if((*lista)->valor==num){
            remover = *lista;
            *lista = remover->prox;
        }
        else{
            aux = *lista;
            while(aux->prox && aux->prox->valor!=num)
                aux = aux->prox;
            if(aux->prox){
                remover = aux->prox;
                aux->prox = remover->prox;
            }
        }
    }

}

int main()
{
    int opcao,valor, anterior;
    No *removido, *lista = NULL;
    do{
        printf("\n\t0 - Sair\n\t1 - InserirI\n\t2 - InserirF\n\t3 - InserirM\n\t4 - Imprimir\n\t5 - Remover\n");
        scanf("%d", &opcao);
        switch(opcao){
        case 1:
            printf("Digite o elemento:");
            scanf("%d", &valor);
            inserir_no_inicio(&lista,valor);
            break;

        case 2:
            printf("Digite o elemento:");
            scanf("%d", &valor);
            inserir_no_fim(&lista,valor);
            break;
        case 3:
            printf("Digite o elemento e a referencia do elemento:");
            scanf("%d%d", &valor, &anterior);
            inserir_no_meio(&lista, valor, anterior);
            break;
        case 4:
            imprimir(lista);
            break;
        case 5:
            printf("Digite um elemento a ser removido");
            scanf("%d", &valor);
            removido = remover(&lista, valor);
            if(removido){
                printf("Elemento a ser removido: %d\n", removido->valor);
                free(removido);
            }


        default:
            if(opcao !=0)
                printf("Op��o inv�lida");}

        }
        while(opcao !=0);


    return 0;
}
