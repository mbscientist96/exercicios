#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int soma(int x, int y);

    int resultado = soma(20,40);
    void divisao();
    float resultdiv = resultado;

    printf("%d \n", resultado);
    printf("%f", resultdiv);
    return 0;
}

int soma(int x, int y){
    int resultado = x+y;
    return resultado;
}
void divisao(){
float   resultdiv = resultado/2;

    return resultdiv ;
}

