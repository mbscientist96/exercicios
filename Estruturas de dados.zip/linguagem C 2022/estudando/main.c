#include <stdio.h>
#include <stdlib.h>
divisao(float x,float y){
     float resultado = x/y;
    return  resultado;

}
float soma(float a, float b){
    float resultsoma = a+b;
    return resultsoma;
}
float resultfinal(float soma, float divisao){
   float resulttudo = soma+divisao;
    return resulttudo;
}

int main()
{
  float resultado = divisao(40,2);
   printf("\n Resultado divisao %f \n", resultado);
 float resultsoma = soma(51,80);
 printf("\n Resultado soma %f \n", resultsoma);
 float resulttudo = resultfinal(resultado,resultsoma);
 printf("\n Resultado final %f \n", resulttudo);
 if (resultado/2){
    printf("numero par");
 }
    return 0;
}
