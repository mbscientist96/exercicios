#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct NO{
    char nome[10];
    char sexo[2];
    int cpf;
} NO;
int main()
{
   NO *p;
   p = (NO*) malloc(sizeof(NO));
   if(p==NULL){
    printf("Erro ao alocar memoria");
   }
   else{
    printf("Insira o nome \n");
    scanf("%s",&p->nome);
    fflush("stdin");

    printf("Insira o sexo \n");
    scanf("%s",&p->sexo);
    fflush("stdin");

    printf("Insira o cpf \n");
    scanf("%d",&p->cpf);
    fflush("stdin");

    printf("Nome %s \n Sexo %s \n CPF %d \n", p->nome, p->sexo, p->cpf);
    system("pause");
    system("cls");

   }

    return 0;
}
