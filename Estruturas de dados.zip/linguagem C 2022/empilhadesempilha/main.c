#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
// Nomes: Matheus Fernando Beraldo
// Bernardo Mesas Castells

typedef struct cel {
    char conteudo;
    struct cel *prox;
} celula;

typedef struct pilha {
    struct cel *cabeca;
} pilha;

void empilha(char c, pilha *p) {
    celula *nova = (celula *) malloc(sizeof(celula));
    nova->conteudo = c;
    nova->prox = p->cabeca;
    p->cabeca = nova;
}

char desempilha(pilha *p) {
    celula *pt = p->cabeca;
    char c = pt->conteudo;
    p->cabeca = pt->prox;
    free(pt);
    return c;
}

int main() {
    char frase[50];
    pilha p;
    p.cabeca = NULL;
    printf("Informe a frase: ");
    fgets(frase, 50, stdin);
    printf(" Invertida: \n ");
    for (int i = 0; frase[i] != '\0'; i++) {
        for (; frase[i] != '\0' && frase[i] != ' '; i++) {
            empilha(frase[i], &p);
        }
        while (p.cabeca != NULL) {
            putchar(desempilha(&p));
        }
        putchar(frase[i] == ' ' ? ' ' : ' ');
    }
    return 0;
}
