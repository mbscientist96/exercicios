#include <stdio.h>

#include <stdlib.h>

#include <conio.h>

#include <math.h>

#define MAX 100

main()

{

int grau, lin, col, count = 1;

int vet_pascal[MAX][MAX];

printf("Digite: ");

scanf("%i",&grau);

for(lin = 1 ; lin <= grau ; lin++){

printf("Grau %i: ",count);

count++;

for(col = 1 ; col <= lin ; col++){

vet_pascal[lin][col] = vet_pascal[lin][col] + 1;

printf("%i ", vet_pascal[lin][col]);

}

printf("\n");

}

system("PAUSE");

return 0;

}






