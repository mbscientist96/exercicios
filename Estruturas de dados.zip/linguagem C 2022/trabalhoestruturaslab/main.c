#include <stdio.h>
#include <stdlib.h>

int main(void)
{

    int *p,i,qtd_elementos;
    int *initVet ( int *size , int *maxSize );
    void printVet ( int *v , int size , int maxSize );
    int *addVet( int *v , int *size , int *maxSize , int e );
    int find(int *v, int size , int e);
    int *removeVet( int *v , int *size , int *maxSize , int e );
    do{
        system("cls");

        printf("\t\t 1 -> Quantidade de elementos em um vetor\n");
        printf("\t\t 2 -> Impress�o do vetor.\n");
        printf("\t\t 3 -> addVet\n");
        printf("\t\t 4 -> Find\n");
        printf("\t\t 5 -> Exclui elemento\n");
        printf("\t\t 6 -> Sair\n");
        scanf("%d%*c",&opcao);
    switch(opcao) {
			case 1: inicio = initVet(&size,&maxSize);
                    if (inicio == 0){
                        printf("Erro ao gerar o vetor");
                    }
                    else {
                        printf("vetor criado com sucesso\n");
                    }
			        system("pause");
					break;

            case 2: printVet(inicio,size,maxSize);
			        system("pause");
					break;

            case 3: printf("\nInforme o valor do elemento: ");
                    scanf("%d",&elemento);
                    inicio = addVet(inicio,&size,&maxSize,elemento);
			        system("pause");
					break;

            case 4: printf("\nInforme o elemento a ser procurado: ");
                    scanf("%d",&elemento);
                    find_elemento = find(inicio,size,elemento);
                    if(find_elemento == -1){
                        printf("\nO elemento %d n�o pertence ao vetor\n",elemento);
                    }
                    else{
                        printf("O elemento %d se est� em v[%d]\n",elemento,find_elemento);
                    }
			        system("pause");
					break;

            case 5: printf("\nInforme o elemento a ser exclu�do: ");
                    scanf("%d",&elemento);
                    inicio = removeVet(inicio,&size,&maxSize,elemento);
                    system("pause");
					break;

			case 6: printf("Saindo...\n");
                    free(inicio);
                    opcao = opcao + 3;
			        system("pause");
					//break;
           default: printf("\n\n Opcao inv�lida");
    }
         system("cls");
    } while (opcao != 9);


    return 0;
}



    printf("Digite a quantidade de elementos do vetor");
    scanf("%d", &qtd_elementos);

        printf("\n");

        for( i=0; i<qtd_elementos; i++){
            printf("Digite o elemento para a posicao [%d] : ",i);
            scanf("%d", &p[i]);
        }
        printf("\n");

           for(i=0; i<qtd_elementos; i++){
            printf("\n elementos da posicao do vetor [%d] = %d\n",i,p[i]);
            printf("Memory %i", &p);
        }
        printf("\n");
        free(p);
        system("pause");
        return 0;


    }


   int *initVet ( int *size , int *maxSize ){

    int *p;
    p = calloc(4, sizeof(int));

    *size = 0;
    *maxSize = 4;

    if (p == NULL){
        return 0;
    }

return p;
}
void printVet ( int *v , int size , int maxSize ){

    for (int i = 0;i < maxSize; i++){
       printf("v[%d]:%d\n",i,v[i]);
    }
    printf("\nsize: %d",size);
    printf("\nmaxSize: %d\n",maxSize);

}
int *addVet( int *v , int *size , int *maxSize , int e ){

    int *p;

    p = v;

    if (*size < *maxSize){
      v[*size] = e;
      *size = *size +1;
    }
    else{
        *maxSize = *maxSize * 2;
        p = calloc(*maxSize, sizeof(int));
        for(int i = 0; i<(*maxSize); i++ ){
            if(i <= *maxSize/2){
                p[i] = v[i];
            }
            else{
                p[i] = NULL;
            }
        }
        free(v);
        p[*size] = e;
        *size = *size +1;
    }
return p;
}


int find(int *v, int size , int e){

    int find_elemento;

    for(int i = 0; i< size; i++){
        if(v[i] == e){
            find_elemento = i;
            break;
        }
        else{find_elemento = -1;}
    }
    return find_elemento;
}


int *removeVet( int *v , int *size , int *maxSize , int e ){

    int posicao_elemento,*p;

    p = v;

    printf("Exclu�ndo elemento %d\n",e);

    posicao_elemento = find(p,*size,e);

    if(posicao_elemento == -1){printf("\nElemento %d n�o encontrado\n",e);}

    else{
        for(int i=0;i<*maxSize;i++){
            if(i >= posicao_elemento){
                p[i] = p[i+1];
            }
        }
        *size = *size -1;
        printf("\nElemento %d exclu�do com sucesso!\n",e);
      }

    if((*size < (*maxSize/4))&&(*maxSize>4)){
       *maxSize = (*maxSize/2);
        p = calloc(*maxSize, sizeof(int));
        for(int i = 0; i<(*maxSize); i++ ){
            if(i <= *maxSize/2){
                p[i] = v[i];
            }
            else{p[i] = NULL;}
        }
        free(v);
        }

 return p;
}




