#include <stdio.h>
#include <stdlib.h>

int main()
{
    float nota1,nota2,nota3,peso1,peso2,peso3, media_numerico;
    scanf("%d",&nota1);
    scanf("%d",&nota2);
    scanf("%d",&nota3);
    scanf("%d",&peso1);
    scanf("%d",&peso2);
    scanf("%d",&peso3);
    media_numerico=(nota1*peso1+nota2*peso2+nota3*peso3)/(peso1+peso2+peso3);
    printf("media %d\n",media_numerico);
    return 0;
}
