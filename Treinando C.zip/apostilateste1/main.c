#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n1,n2,n3,n4,soma_numerico;
    scanf("%d",&n1);
    scanf("%d",&n2);
    scanf("%d",&n3);
    scanf("%d",&n4);
    soma_numerico=n1+n2+n3+n4;
    printf("total %d",soma_numerico);
    return 0;
}
