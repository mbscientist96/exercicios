#include <stdio.h>
#include <stdlib.h>


int main()
{
    int multiplicacao = 0;
    printf("\nDigite a tabuada que voce deseja \n ");
    scanf("%i", &multiplicacao);

    for(int x = 1; x<=10; ++x){

        printf("%ix%i = %i\n", x, multiplicacao, x * multiplicacao);
    }

    return 0;
}
