#include <stdio.h>
#include <stdlib.h>

int main()
{

    float nota1,nota2,nota3,media,falta;
    printf("Digite as 3 notas do aluno\n");
    scanf("%f",&nota1);
    scanf("%f",&nota2);
    scanf("%f",&nota3);
    printf("Digite a quantidade de faltas\n");
    scanf("%f",&falta);
    media=nota1+nota2+nota3/2;
    if(media<7){
        printf( "O aluno Matheus foi reprovado por falta de media\n");
    }
    else{
        printf("O aluno Matheus foi aprovado por media\n");
    }
    if (falta>=20){
        printf("O aluno Matheus foi reprovado por faltas\n");

    }
    else{
        printf("O aluno Matheus foi aprovado por faltas\n");
    }

    return 0;
}
