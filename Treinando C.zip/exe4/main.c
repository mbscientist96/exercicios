#include <stdio.h>



int main()

int i;
int numero, par, impar;


for(i=1;i<=10;i++){
printf("Digite um numero:");
scanf("%d%*c",&numero);
if (numero%2==0){
numero = par;
printf("\nNumeros par: %d",par);
}
else
numero = impar;
printf("\nNumeros impares: %d",impar);
}

return 0;
}
