#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n1,n2,m;
    printf("digite dois numeros");
    scanf("%d",&n1);
    scanf("%d",&n2);
    m=n1*n2;
    printf("resultado = %d",m);

    return 0;
}
