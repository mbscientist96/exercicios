#include <stdio.h>
#include <stdlib.h>
// criar um programa em for para ler a idade de 5 pessoas e calcular a media e a soma
int main()
{
    int pessoa,idade,media,soma=0;
    for(pessoa=1;pessoa<=5;pessoa++){
printf("\nDigite a idade das 5 pessoas\n");
    scanf("%d*c",&idade);
    soma=soma+idade;

    }
    media=soma/5;
    printf("\n valor soma%d\n",soma);
    printf("\n valor media %d\n",media);
    return 0;
}
