#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "");

    int codigo, x, boi_gordo, boi_magro;
    float peso, gordo, magro, somapeso;
    somapeso = 0;

    for(x=1; x<=7; x++){
        printf("\n  %d� boi", x);
        printf("\n\tPeso(Kg): ");
          scanf("%f%*c", &peso);
        printf("\tC�digo: ");
          scanf("%d%*c", &codigo);
        somapeso = somapeso + peso;

        if(x == 1){
            gordo = magro = peso;
            boi_gordo = boi_magro = codigo;
        }
        else{
            if(peso > gordo){
                gordo = peso;
                boi_gordo = codigo;
            }
            if(peso < magro){
                magro = peso;
                boi_magro = codigo;
            }
        }

    }

    printf("\n  O boi mais gordo pesa %.1f Kg e seu c�digo �: %d", gordo, boi_gordo);
    printf("\n  O boi mais magro pesa %.1f Kg e seu c�digo �: %d", magro, boi_magro);
    printf("\n  A m�dia de peso dos bois � %.1f Kg\n", somapeso/7);

    return 0;
}
