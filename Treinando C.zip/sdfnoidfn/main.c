#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x,d,y,z,resultado;
    printf("DIGITE QUANTOS HOMENS DISSERAM SIM");
    scanf("%d",&x);
    printf("DIGITE QUANTOS HOMENS DISSERAM NAO");
    scanf("%d",&d);
    printf("DIGITE A QUANTIDADE DE MULHERES QUE DISSERAM SIM");
    scanf("%d",&y);
    printf("DIGITE A QUANTIDADE DE MULHRES QUE DISSERAM NAO");
    scanf("%d",&z);
     printf("A quantidade de mulheres que disseram sim e de %d \n",y);
      printf("A quantidade de mulheres que disseram nao e de %d \n",z);
    printf("A quantidade de homens que disseram sim e de %d \n",x);
    printf("A quantidade de homens que disseram nao e de %d \n",d);
    return 0;
}
