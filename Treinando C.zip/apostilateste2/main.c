#include <stdio.h>
#include <stdlib.h>

int main()
{
    int nota1,nota2,nota3, media_numerico;
    scanf("%d",&nota1);
    scanf("%d",&nota2);
    scanf("%d",&nota3);
    media_numerico=(nota1+nota2+nota3)/3;
    printf("media %d",media_numerico);
    return 0;
}
