#include <stdio.h>
#include <stdlib.h>
// programar um sistema de uma locadora de filmes que contenha cadastro de pessoas, qual filme levar� e quando deve pagar
int main()

char nome = 'w';

{
    printf("Digite o nome da pessoa\n");
    scanf("%c", &nome);
    printf("nome\n %c",nome);
    return 0;
}
