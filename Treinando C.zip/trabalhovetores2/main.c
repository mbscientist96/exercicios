#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <math.h>
 int main()
{
setlocale(LC_ALL,"Portuguese");
int x;
char frase  [4];
char frase1 [4];
char frase2 [4];
char frase3 [4];

printf ("Digite uma frase:");
scanf ("%s%s%s%s",&frase,&frase1,&frase2,&frase3);

for (x=1;x<=3;x++){

}
printf ("\n:%s",frase);
printf ("\n:%s",frase1);
printf ("\n:%s",frase2);

printf ("\n:%s",frase3);


    return 0;
}
