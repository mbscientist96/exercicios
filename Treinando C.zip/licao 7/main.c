#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int delta,a,b,c,raiz_delta;
     printf("digite os numeros da equacao");
     scanf("%d",&a);
     scanf("%d",&b);
     scanf("%d",&c);
     scanf("%d",&raiz_delta);
     delta=b*b-4*a*c;
     raiz_delta=sqrt(delta);
     if(raiz_delta>0){
        printf("Essa equa��o foi feita de duas raizes reais");
     }
     if(raiz_delta<0){
        printf("Essa equa��o nao havera raizes reais");

     }
     if(raiz_delta==0){
        printf("Essa equa��o havera raizes reais e iguais");
     }

    return 0;
}
