#include <stdio.h>
#include <stdlib.h>


int main()
int par,impar,somapar,somaimpar,x,y;
par=0;
impar=0;
somapar=0;
somaimpar=0;
for(par=1;impar=10;x+par;x+impar){
    if x=par+2{
          printf("numeros pares %d",x);

        }
    if x=imapar+1{
        print("numero impar %d",x);
    }
    if x=x+par{
        printf("quantidade de numeros pares %d",x);
    }
    if x=x+impar{
        printf("quantidade de numeros impares %d",x);
    }

}
