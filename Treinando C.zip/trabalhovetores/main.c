#include <iostream>;
using namespace std;
int main(){

    int cod_produto[10] = {1,2,3,4,5,6,7,8,9,10};
        int total_est[10]   = {8,3,20,40,33,60,7,8,9,10};
         int cod_client,produto,quantidade;
           int i;
              while(1)    {        cout<<"Digite o Codigo do Produto, Cliente e Quantidade\n: ";
                    cin>>produto>>cod_client>>quantidade;
                      if (cod_client == 0)
                            break;
                      for(i=0; i<10; i++)        {
                                    if (produto == cod_produto[i])            {
                                                  cout<<endl<<"Tentar Atender o Pedido.."<<endl;
                      if (quantidade <= total_est[i])                {                    cout<<"Pedido Atendido! Obrigado e volte sempre."<<endl<<endl;                    total_est[i] -= quantidade;                }                else                {                    cout<<"Nao temos estoque suficiente..."<<endl<<endl;                }                break;            }        }        if (i == 10)            cout<<endl<<"Codigo inexistente!"<<endl<<endl;    }    cout<<endl<<endl<<"Estoque Atualizado:"<<endl;    for(i=0; i<10; i++)    {        cout<<"Produto: "<<cod_produto[i]<<" - Estoque: "<<total_est[i]<<endl;    }    return 0;}
