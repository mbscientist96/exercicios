#include <stdio.h>
#include <stdlib.h>

int main()
{

  int x;

printf("Numero?\n");

scanf("%d", &x);

if(x%5==0){

printf("O numero e divisivel por 5\n");
}

else

printf("nao e divisivel por 5!\n");

    return 0;
}
