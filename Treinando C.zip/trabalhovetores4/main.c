#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define TAM 7
#include <locale.h>

int main(){
    setlocale(LC_ALL,"Portuguese");
	int matricula[TAM], iMaior=0, i;
	float media[TAM], vMaior=0, nMinima;


	for (i = 0; i < TAM; i++){
		printf("Informe a matricula do aluno[%i](*somente n�meros)\n", i);
		scanf("%i", &matricula[i]);
	}


	for (i = 0; i < TAM; i++){
		printf("Informe a m�dia do aluno[%i] de Matricula:%i\n", i, matricula[i]);
		scanf("%f", &media[i]);


		if(media[i]>vMaior){
			vMaior = media[i];
			iMaior = i;
		}
	}


	printf("Maior m�dia � %f do aluno[%i] de matricula:%i \n", vMaior, matricula[iMaior], iMaior);


	for (i = 0; i < TAM; i++){
		if(media[i]<7){

			nMinima = 25-(media[i]*4);
			if(nMinima>10){
				printf("O aluno[%i], Matricula:%i reprovado\n", i, matricula[i]);
			} else {
				printf("O aluno[%i], Matricula:%i precisa de %f para ser aprovado\n", i, matricula[i], nMinima);
			}
		}
	}

	return 0;
}
