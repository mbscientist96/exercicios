#include <stdio.h>
#include <stdlib.h>

int main()
{
    float salario_atual,novo_salario;
    printf("digite o salario atual do funcionario");
    scanf("%f", &salario_atual);
    if(salario_atual>500){
        salario_atual*1.20;
        printf("novo salario aumento ",%f);
    }
        else(salario_atual<500){
                salario_atual-100
                printf("n�o ter� aumento "%f);

        }

}

    return 0;
}
