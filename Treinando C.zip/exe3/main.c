#include <stdio.h>
#include <stdlib.h>



int main()
{
int i;
float soma, numero, media;


for(i=1;i<=5;i++){
printf("Digite um numero:");
scanf("%f%*c",&numero);

}
soma = soma + numero;
media = soma / 5;
printf("\nSoma: %f",soma);
printf("\nMedia: %f",media);


return 0;
}

