#include <stdio.h>
#include <stdlib.h>

int main()
{
    int valorcarro,total;
    printf("Digite o valor do novo carro!\n");
    scanf("%d",&valorcarro);

    if (valorcarro<=12000){
       total=valorcarro*1.05;
        printf("\nvoce comprou um carro de ate 12000 portanto pagara %d\n",total);


}
   else  if
        ((valorcarro>=12000 && valorcarro<=25000)){
        valorcarro*25;
        total=valorcarro;
        printf("/n voce comprou um carro entre valores de 12000 e 25000 portanto pagara%d /n",total);
        }

        else if  (valorcarro>=25000){
            valorcarro*35;
            total=valorcarro;
             printf("/n voce comprou um carro de valor a cima de 25000 portanto pagara%d /n",total);

        }
    return 0;
}
