#include <stdio.h>
#include <stdlib.h>

int main()
{
    int sal, novosal;
    scanf("%d",&sal);
    novosal=sal+sal*25/100;
    printf("NOVO SALARIO %d!\n",novosal);
    return 0;
}
