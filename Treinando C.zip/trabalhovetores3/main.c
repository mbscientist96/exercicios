#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{

    setlocale(LC_ALL, "Portuguese");


    int vet[8],x,y,i,soma;
    for(i=1;i<=8;i++)
{
        printf("Digite o %i vetor:",i);
            scanf("%d",&vet);
}
             x=vet[5];
             y=vet[7];
        printf("O valor do vetor X e: %i\n",x);
        printf("O valor do vetor Y e: %i\n",y);
            soma=vet[5]+vet[7];

        printf("\n A soma de X e Y e: %i",soma);
return 0;
}
