#include <stdio.h>
#include <stdlib.h>
// fazer um programa em c que mostre os numeros pares em decrescente de 100 a 0
int main()
{
    int x;
   for(x=100;x>=0;x=x-2){

        printf(" valor %d\n",x);
    }


    return 0;
}
