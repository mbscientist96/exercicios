#include <stdio.h>
#include <stdlib.h>

#include <stdio.h>


int main()
{
int x;

//mostrar os impares entre 0 e 100
for(x = 100; x > 0; x = x - 2){ //x++

printf("\nValor de x=%d",x);
}

return 0;
}
