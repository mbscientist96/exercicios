
#include <stdio.h>
#include <stdlib.h>



int main
{
float SA, SN;
printf("Digite o sal�rio atual do funcion�rio:\n");
scanf("%f", &SA);
if (SA<=500)
SN=SA*1.20;
printf("O novo sal�rio ser� de: %f", SN);
else
SN=SA*1.10;
printf("Seu novo sal�rio ser�:\n %f", SN);



return 0;
}
