#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;
    printf("digite um numero");
    scanf("%d",&n);
    if(n%2){
            printf("numero impar");
    }
    else{
        printf("numero par");
    }
    return 0;
}
