#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n1,n2;
    printf("Digite um numero");
    scanf("%d",&n1);
    scanf("%d",&n2);
    if(n1!=n2){
        printf("esses numeros nao sao iguais");
    }
    else {
        printf("esses numeros sao iguais");
    }
    return 0;
}
