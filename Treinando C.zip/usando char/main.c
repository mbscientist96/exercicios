#include <stdio.h>
#include <stdlib.h>

int main()
{
   char nome,filme;
   int valor;
   printf("Digite um filme\n");
   scanf("%s",&filme);
   printf("Digite um nome\n");
   scanf("%s",&nome);
   printf("Digite o valor do filme");
   scanf("%d",&valor);
   printf("filme%s",filme);
   printf("nome%s",nome);
   printf("valor%d", valor);


    return 0;
}
