#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n1,n2;
    printf("digite um numero");
    scanf("%d",&n1);
    scanf("%d",&n2);
    if(n1>n2){
        printf("o numero maior e de %d",n1);
    }
        else{
            printf("o numero maior e de %d",n2);
        }


    return 0;
    }

