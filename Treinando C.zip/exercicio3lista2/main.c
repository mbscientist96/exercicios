#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,a,b,c, media_aritmetica,media_ponderada;
    printf("Digite o valor de I");
    scanf("%d", &i);
    printf("Digite o valor de A");
    scanf("%d", &a);
    printf("Digite o valor de B");
    scanf("%d", &b);
    printf("Digite o valor de C");
    scanf("%d", &c);
     if ((i%2==0)&&(media_aritmetica=a+b+c/3)){
        printf("A media aritmetica e de %d",media_aritmetica);
     }
     else{
          media_ponderada=a+b+c/2+3+4;
        printf("A media ponderada sera de %d",media_ponderada);
     }


// AO DIGITAR NUMERO PAR PARA "I", SER� CALCULADO A MEDIA ARITMETICA, SE N�O SER� A MEDIA PONDERADA


    return 0;
}
