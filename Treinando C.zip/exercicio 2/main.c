#include <stdio.h>
#include <stdlib.h>

int main()
{
    float n1,n2,d;
    printf("Digite dois numeros");
    scanf("%f",&n1);
    scanf("%f",&n2);
    if(n2==0){
        printf("impossivel dividir");
    }
    else{ d=n1/n2;
        printf("resultado = %f",d);

        }
    return 0;
}
