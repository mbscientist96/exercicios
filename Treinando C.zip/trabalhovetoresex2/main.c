#include <stdio.h>
#include <stdlib.h>

int main()
{
    #include <stdio.h>
#include <stdlib.h>

int main()
{
    int vet[11],i;
    vet[0]=1;
    vet[1]=3;
    vet[2]=5;
    vet[3]=7;
    vet[4]=9;
    vet[5]=11;
    vet[6]=13;
    vet[7]=15;
    vet[8]=17;
    vet[9]=19;
    vet[10]=21;
    i=vet;
 printf("Digite o valor:");
    for(i=0;i<11;i++){

        scanf("%d%*c",&vet[i]);
    }
    for(i=0;i<10;i++){
        printf("\nValores:%d",vet[i]);
    }

    return 0;
}
}
