#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "");

    int permicao, senha, x;
    permicao = 101010;

    for(x=2; x>=0; x--){
        printf("\n  Digite a senha: ");
          scanf("%d%*c", &senha);
        if(senha == permicao){
            printf("\tSenha Correta\n");
            break;
        }
        else{
            printf("\tSenha incorreta, voc� s� tem mais  %d tentativas\n", x);
        }
    }

    return 0;
}
