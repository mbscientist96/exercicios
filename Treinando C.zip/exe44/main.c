#include <stdio.h>
#include <stdlib.h>



int main()
{
int i;
int numero, par, impar;


for(i=1;i<=10;i++){
printf("Digite um numero\n:");
scanf("%d%*c",&numero);
if (numero%2==0)
{
printf("\nNumeros par: %d\n",numero);
}

else {

printf("\nNumeros impar: %d",numero);
}
}

return 0;
}
