#include <stdio.h>
#include <stdlib.h>

int main()

{
    int a,b;
    printf("digite um numero");
    scanf("%d",&a);
    scanf("%d",&b);
    if(a>=1);{
    printf("numero menor %d",b);
      (b<=10);
      printf("numero maior %d",a);
    }


    return 0;
}
