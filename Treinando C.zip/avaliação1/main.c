#include <stdio.h> // biblioteca de comando padr�o
#include <stdlib.h>  // bliblioteca de comando padr�o
#include <locale.h> // biblioteca de comando de linguagens
#include <math.h> // biblioteca para realizar os calculos matematicos

int main()
{
    setlocale(LC_ALL,"Portuguese"); // biblioteca para aceitar caracteres de portugues como acentos nas frases.


int x,y,adiciona=0,maior=0,menor,medpar=0,soma=0; // vari�veis para armazenamento de numeros inteiros

float media=0; // vari�vel float, serve para usar em numeros flutuantes ou seja numeros decimais, EX: 10,5. 11,3. 2,5.....


printf("Digite os numeros:\n"); // printf exibe a frase digitada (frase digitada )



for(y=0;y<5;y++){ // estrutura de repeti��o, repete quantas vezes for declarado o numero, e incrementa o numero digitado

   scanf("%d", &x); // l� o numero que foi digitado

   soma=soma+x; // soma do numero digitado

   adiciona++; // incrementa de 1 em 1

   if(maior<x){ // condi��o "Se" for maior

       maior=x; // armazena a variavel maior em x

   }

   if(menor>x){ // condi��o "Se" for menor

       menor=x;// armazena a variavel menor em x

   }

   if(x%2==0){ // condi��o "Se" for resto da divis�o

       medpar=medpar+x;// calcula a media do par

   }

}

media=soma; // armazena a media como soma

media=media/5; // armazena o resultado da m�dia dividido por 5



printf("\n Quantidade total dos numeros digitados: %d",adiciona);  // exibe a frase digitada e a quantidade de numeros digitados %d, adiciona
printf("\n Valor do menor numero digitado: %d",menor); // exibe a frase na tela e o valor do menor numero
printf("\n Valor da media dos numeros: %.2f",media); // exibe a frase na tela e o valor da media dado em numero flutuante (decimais) %.2f,media
printf("\n Valor da media dos numeros pares: %d",medpar); // exibe a frase na tela e o valor da media do numero par
printf("\n Valor da soma: %d",soma); // exibe a frase digitada e o valor da soma que � dado em %d,soma
printf("\n Valor do maior numero digitado: %d",maior); // exibe a frase na tela e o valor do maior numero

}
