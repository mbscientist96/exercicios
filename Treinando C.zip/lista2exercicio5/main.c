
#include<stdio.h>
#include<locale.h>

int main()
{
  float altura,largura,comprimento,consumo,capacidade,autonomia;
  setlocale(LC_ALL,"portuguese");

  printf("\n\t Resevart�rio de �gua\n");
  printf("\n Digite a altura (cm): ");
  scanf("%f",&altura);
  printf("\n Digite a largura (cm): ");
  scanf("%f",&largura);
  printf("\n Digite o comprimento (cm): ");
  scanf("%f",&comprimento);

  printf("\n Consumo diario de litros por dia = ");
  scanf("%f",&consumo);

  capacidade=(altura*largura*comprimento)/1000;
  autonomia=capacidade/consumo;

  printf("\n Capacidade do Reservat�rio= %.1f litros ",capacidade);
  printf("\n Autonomia do reservat�rio= %.1f dias",autonomia);

  if(autonomia<2)
   {
     printf("\n Consumo Elevado \n");
   }
  else if(autonomia>=2 && autonomia<=7)
     {
       printf("\n Consumo Moderado \n");
     }
 else if(autonomia>7)
        {
          printf("\n Consumo Baixo");
        }
return 0;
}
//apanhei nessa ultima quest�o, mas depois que descobri a fun��o "else if" junto, j� matei a charada kkk
