#include <stdio.h>
#include <stdlib.h>

int main()
{
    char batatafrita[12];
    printf("digite a senha do gordo\n");
    scanf("%c",&batatafrita);
    if (strcmp(batatafrita)==0{
        printf("acesso gordo permitido\n");
        }

    else{
        printf("n�o foi dessa vez gordo\n");
    }
    return 0;
}
