#include <stdio.h>
#include <stdlib.h>

int main()
float n1,n2,m;
printf("digite sua nota");
scanf("%f",&n1);
scanf("%f",&n2);
media=n1+n2/2;
if(m>==7){
    printf("aluno aprovado%f",m);

}
else{ (m<=7)
    printf("aluno reprovado%f",m);

{

    return 0;
}
