#include <stdio.h>
#include <stdlib.h>

int main()
{
    int salario,gasto,resultado;
    printf("Digite o salario\n");
    scanf("%d",&salario);
    printf("Digite o gasto");
    scanf("%d",&gasto);
    salario-gasto;
    resultado=salario-gasto;
    if (gasto>=salario){
        printf("orcamento estourado %d",resultado);

    }
    else{
        printf("gasto dentro do orcamento %d",resultado);
    }

    return 0;
}
