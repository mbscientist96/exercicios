#include <stdio.h> // bibliotecas  de comando padr�o
#include <stdlib.h> // bibliotecas de comando padr�o
#include <locale.h> // biblioteca de comando de  linguagem
#include <math.h> //biblioteca de comandos matematicos


int main(){
    int n=6,x,k,y=0; // declara��o de variaveis de armazenamento de numeros inteiros

    for(x=1;x<=n;x++){ // estrutura de repeti��o come�ando em 1 at� o 6 e incrementando um numero
     for(k=1;k<= x; k++) { // estrutura de repeti��o come�ando k em 1 novamente ap�s o x passar a ser 6 e incrementando um numero
        y++;// incrementa��o da variavel
        printf("%d",y); //mostra o valor da variavel ap�s ter sido incrementado
     }

        printf("\n"); // pulando as linhas dos numeros
    }
}
