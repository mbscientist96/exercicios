#include <stdio.h>
#include <stdlib.h>
// somar a media de 10 alunos
int main(void)
{
  float notas[10]={0};
  float media=0;
  float total=0;
  int i;
  printf("Digite a nota de 10 alunos");
  for(i=0;i<=10; i++)

    scanf("%f",&notas[i]);

for(i=0;i<=10;i++)
    total+=notas[i];
    media=total/10;

    printf("A MEDIA FINAL SERA DE %f",media);

    return 0;
}

