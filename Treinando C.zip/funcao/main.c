
#include <stdio.h>
#include <stdlib.h>

#include <stdio.h>



void subtrai();

int diferenca();



int main()

{

    int x, y;

    //soma();

    //x = soma3();

    //printf("\nSoma: %d", x);



    subtrai();

    printf("\n\n");

    y = diferenca();

    printf("A diferenca e %d.", y);



    return 0;

}





void subtrai(){

    int a, b, sub;

    printf("Sera subtraido o 2 do 1 valor.\n");

    printf("Digite 2 valores: ");

    scanf("%d%d*%c", &a,&b);

    sub = a-b;

    printf("Subtracao: %d.", sub);

}



int diferenca(){

    int a, b, sub;

    printf("Sera subtraido o 1 do 2 valor.\n");

    printf("Digite 2 valores: ");

    scanf("%d%d*%c", &a,&b);

    sub = b-a;

    return sub;

}
