#include <stdio.h>
#include <stdlib.h>

int main()
{
    int salario1,percentual,aumento,novosalario1;
    scanf("%d",&salario1);
    scanf("%d",&percentual);
    aumento=salario1*percentual/100;
    printf("Escreva aumento");
    novosalario1=salario1+aumento;
    printf("Novo salario e de %d",novosalario1);


    return 0;
}
