#include <stdio.h> // biblioteca padr�o
#include <stdlib.h> // bibliotecas padr�o
#include <locale.h> // biblioteca  de comando de linguagem
#include <math.h> // biblioteca biblioteca de comandos matem�ticos


int main()  //�nicio do programa
{

 int i, x, y; // armazena os numeros inteiros nas variaveis
 x = 0; //

  printf("Digite um numero inteiro:"); // exibe mensagem na tela
  scanf("%d", &i); // l� numero digitado

  for(y=1; y<=i; y++) // estrutura de repeti��o for onde y come�a em 1 e termina menor igual a i
{
  if((i % y) == 0)  //   Condi��o "Se" caso o resto for y
  {
   x=x+y;            //     x � amazenado em x  + a soma
  }
}
printf("\nSoma dos divisores: %.2d", x - i); // imprime a soma de todos os divisores

 return 0;  // retorno da fun��o main
}
