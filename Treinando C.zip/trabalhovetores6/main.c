#include <stdio.h>
#include <locale.h>

    int main(void){setlocale(LC_ALL, "Portuguese");

    int vetor[40], aux, x = 1;

    for(aux = 0; aux < 40; aux++){

        printf("Insira o vetor: ");
        scanf("%d", &vetor[aux]);

        if(vetor[aux] < 40)vetor[aux] = 0;
    }

    for(aux = 0; aux < 5; aux++){

        printf("\t\n%d� - %d", x, vetor[aux]);
        x++;

    }
}
