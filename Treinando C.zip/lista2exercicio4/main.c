#include <stdio.h>
#include <stdlib.h>

int main()
{
    int time1,time2;
    printf("Digite a quatidade de gols do time 1\n");
    scanf("%d", &time1);
    printf("Digite a quantidade de gols do time 2\n");
    scanf("%d", &time2);

    if (time1>time2){
        printf("o time 1 e o vencedor com total de gols\n %d",time1);
    }
    if (time1=time2){
        printf("empate");
    }
    else{
        printf("o time 2 e o vencedor com total de gols\n %d",time2);
    }


    return 0;
}
