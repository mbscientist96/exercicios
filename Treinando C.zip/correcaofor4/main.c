#include <stdio.h>
#include <stdlib.h>

int main()
{
   int i,num,somapar,somaimpar;
   for(i=1;i<=10;i++){
    printf("Digite os numeros inteiros");
    scanf("%d",&num);
    if(num%2==0){
        somapar++;
    }
    else{
        somaimpar++;
    }
    printf("\n valores pares %d \n",somapar);
    printf("\n valores impares %d \n",somaimpar);

   }

}
