#include <stdio.h> // bibliotecas padr�o
#include <string.h> // bibliotecas padr�o
int main(){ // inicio do programa

int N, E = 1, x, y, num, fator; // armazenamento de numeros inteiros nas variaveis

printf("Digite um numero: "); // exibe mensagem na tela

scanf("%d", &N); // l� o numero digitado

for(x=1; x<=N; ++x){ // estrutura de repeti��o sendo que x come�a em 1 e termina em N
 num = 1.0/x; //armazena a variavel num, dividindo a variavel x por 1.0
 fator = 1; // armazena o valor do fator = 1
 for(y=num; y>0; --y){ // estrutura de repeti��o para calcular o fator
  fator*=num; // define a variavel fator vezes a variavel num
 }
 E += fator; //"E" � somado ao fator do resultado da divis�o
}

printf("Valor de 'E': %d", E); // exibe o valor de E
  return 0;
}
