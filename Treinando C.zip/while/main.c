#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;

    x=1;
    while(x!=1){
        printf("Digite um numero");
        scanf("%d"&x);
    }
    printf("Hello world!\n");
    return 0;
}
