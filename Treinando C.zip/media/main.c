#include <stdio.h>
#include <stdlib.h>

int main()
{
   float n1,n2,m;
   printf("Digite as duas notas");
   scanf("%f",&n1);
   scanf("%f",&n2);
    m=(n1+n2)/2;
    if(m>=7){
        printf("aprovado");
    }
    else(m<=7){
        printf("reprovado");
    }
    return 0;
}
