#include <stdio.h>
#include <stdlib.h>
// fa�a um programa em c, utilizando o for, para exibir todos os numeros multiplos de 3 entre 10 e 51.
int main()
{
    int x,resto;
    for(x=10;x<=51;x++){
    resto=x%3;
    if (resto==0){
       printf("valor %d\n",x);
    }
    }

    return 0;
}
