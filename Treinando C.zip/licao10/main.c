#include <stdio.h>
#include <stdlib.h>

int main()
{
    int numero;
    printf("digite um numero\n");
    scanf("%d",&numero);
    if(numero>=20&numero<=90){
        printf("numero compreendido\n");
    }
    else{


        printf("numero nao compreendido\n");
    }


    return 0;
}
