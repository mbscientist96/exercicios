#include <stdio.h>
#include <stdlib.h>

int main()
{
    int na,nb;
    printf("digite um numero");
    scanf("%d",&na);
    scanf("%d",&nb);
    if (na%nb){
        printf("os numeros nao sao divisiveis");

    }
    else{
        printf("os numeros sao divisiveis");
    }
    return 0;
}
