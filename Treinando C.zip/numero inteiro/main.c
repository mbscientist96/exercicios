#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;
    printf("Digite um numero");
    scanf("%d",&n);
    if (n>10){
    printf("esse numero e maior que 10 %d",n);

    }
    else {(n<10);
    printf("esse numero e menor que 10 %d",n);

    }
    return 0;
}
