#include <stdio.h>
#include <math.h>


int qtd1,qtd2;

printf("Digite quantos homens responderam sim");
scanf("%d",&qtd1);

printf("Digite quantos homens responderam nao");
scanf("%d",qtd1);


printf("Digite quantas mulheres responderam sim");
scanf("%d",qtd2);

printf("Digite quantas mulheres responderam n�o");
scanf("%d",qtd2);


}
return 0;
}
