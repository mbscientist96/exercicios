#include <stdio.h>
#include <stdlib.h>

int main()
{
int x,y,z;

y=3;
for(x=10;x<=51;x++){
    z=x*y;
    printf("%d\n",z);
}
return 0;
}
